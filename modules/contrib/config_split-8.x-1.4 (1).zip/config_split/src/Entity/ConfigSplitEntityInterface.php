<?php

namespace Drupal\config_split\Entity;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Configuration Split Setting entities.
 */
interface ConfigSplitEntityInterface extends ConfigEntityInterface {

}
